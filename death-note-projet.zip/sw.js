// Service worker de Death Note.
// Le numéro de version est remplacé à chaque publication (voir site.yml).
const VERSION = '__VERSION__';
const CACHE = 'death-note-' + VERSION;
const LIBS = 'libs-v1';
const POSTERS = 'posters-v1';
const POSTER_HOSTS = ['image.tmdb.org', 'covers.openlibrary.org'];
const SHELL = ['./', 'index.html', 'manifest.json', 'firebase-config.js', 'icon-192.png', 'icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('death-note-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Fichiers de l'app : on répond tout de suite avec le cache, et on met à jour en arrière-plan.
  if (url.origin === location.origin) {
    e.respondWith(
      caches.open(CACHE).then(async (cache) => {
        const cached = await cache.match(req, { ignoreSearch: true });
        const refresh = fetch(req).then((res) => {
          if (res && res.ok) cache.put(req, res.clone());
          return res;
        }).catch(() => cached);
        if (cached) { e.waitUntil(refresh); return cached; }
        return refresh;
      })
    );
    return;
  }

  // Bibliothèques Firebase : gardées en cache pour fonctionner hors connexion.
  if (url.hostname === 'www.gstatic.com' && url.pathname.indexOf('/firebasejs/') === 0) {
    e.respondWith(
      caches.open(LIBS).then(async (cache) => {
        const cached = await cache.match(req);
        if (cached) return cached;
        const res = await fetch(req);
        cache.put(req, res.clone());
        return res;
      })
    );
  }
  // Affiches : gardées en cache pour s'afficher hors connexion (on garde les 600 plus récentes).
  if (POSTER_HOSTS.indexOf(url.hostname) !== -1) {
    e.respondWith(
      caches.open(POSTERS).then(async (cache) => {
        const cached = await cache.match(req);
        if (cached) return cached;
        const res = await fetch(req);
        cache.put(req, res.clone()).then(() => cache.keys()).then((keys) => {
          if (keys.length > 600) cache.delete(keys[0]);
        });
        return res;
      })
    );
  }
  // Tout le reste (Firestore, connexion Google, recherche de titres) passe directement par le réseau.
});
