// Configuration Firebase de Death Note (projet death-note-27db3).
// Ces identifiants ne sont pas secrets : la protection des données repose sur les règles Firestore.

window.DEATHNOTE_FIREBASE = {
  apiKey: "AIzaSyBG617O1tgDd08FrhOzgWysIbaR4NMa1wo",
  authDomain: "death-note-27db3.firebaseapp.com",
  projectId: "death-note-27db3",
  storageBucket: "death-note-27db3.firebasestorage.app",
  messagingSenderId: "94032636106",
  appId: "1:94032636106:web:a48fa25081f31f7d736c33"
};
